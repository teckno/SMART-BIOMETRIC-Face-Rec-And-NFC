import sys
from PyQt4.QtCore import *
from PyQt4.QtGui import *
import cv2
class filedialogdemo(QWidget):
   def __init__(self, parent = None):
      super(filedialogdemo, self).__init__(parent)
		
      layout = QVBoxLayout()
      self.btn = QPushButton("Select File")
      self.btn.clicked.connect(self.getfile)
		
      layout.addWidget(self.btn)
      self.le = QLabel("Hello")
		
      layout.addWidget(self.le)
      self.btn1 = QPushButton("QFileDialog object")
      self.btn1.clicked.connect(self.getfiles)
      layout.addWidget(self.btn1)
		
      self.contents = QTextEdit()
      layout.addWidget(self.contents)
      self.setLayout(layout)
      self.setWindowTitle("Photogeniks")
		
   def getfile(self):
      fname = QFileDialog.getOpenFileName(self, 'Open file', 
         'c:\\',"Image files (*.jpg *.gif)")
     
      cascPath = "haarcascade_frontalface_default.xml"
      de= str(fname)

    # Create the haar cascade
      faceCascade = cv2.CascadeClassifier(cascPath)

    # Read the image
      image = cv2.imread(de)
      gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Detect faces in the image
      faces = faceCascade.detectMultiScale(
              
          gray,
          scaleFactor=1.1,
          minNeighbors=5,
          minSize=(30, 30),
          flags = cv2.cv.CV_HAAR_SCALE_IMAGE
      )
      
      

      minisize = (image.shape[1],image.shape[0])
      miniframe = cv2.resize(image, minisize)

      faces = faceCascade.detectMultiScale(miniframe)

      for f in faces:
         x, y, w, h = [ v for v in f ]
         cv2.rectangle(image, (x,y), (x+w,y+h), (255,255,255))

         sub_face = image[y:y+h, x:x+w]
         face_file_name = "Faces/face_" + str(y) + ".jpg"
         cv2.imwrite(face_file_name, sub_face)

      


      print("Found {0} faces!".format(len(faces)))

    # Draw a rectangle around the faces
      for (x, y, w, h) in faces:
           cv2.rectangle(image, (x, y), (x+w, y+h), (0, 255, 0), 2)

           
      self.le.setPixmap(QPixmap(de))
      cv2.imshow("Faces found", image)
      cv2.waitKey(0)
      
      

		
   def getfiles(self):
      dlg = QFileDialog()
      dlg.setFileMode(QFileDialog.AnyFile)
      dlg.setFilter("Text files (*.txt)")
      filenames = QStringList()
		
      if dlg.exec_():
         filenames = dlg.selectedFiles()
         f = open(filenames[0], 'r')
			
         with f:
            data = f.read()
            self.contents.setText(data)

   
				
def main():
   app = QApplication(sys.argv)
   ex = filedialogdemo()
   ex.show()
   sys.exit(app.exec_())
	
if __name__ == '__main__':
   main()
